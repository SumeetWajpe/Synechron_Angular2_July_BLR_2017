function    Add(x,y){
    return x + y;
}

describe("A suite", function() {
  it("contains spec with an expectation", function() {
    expect(true).toBe(true);
  });
});

describe("A addition test Suite", function() {
  it("checks the addition of two numbers", function() {
    expect(Add(10,20)).toBe(30);
  });
});