"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
// import {ICourse} from './iCourse.interface';
// @Component({
//   selector: 'my-app',
//   // template: `<course [coursedetails]="course1Info"></course>
//   // <course [coursedetails]="course2Info"></course>`,
// // template:`
// // <h1> Courses :</h1>
// // <div *ngFor="let c of courses">
// //       <course [coursedetails]="c"></course>
// // </div>
// // `
// templateUrl:'./app/app.component.html'
// })
// export class AppComponent  { 
//   // course1Info:ICourse={ 
//   //     name : 'ReactJS',
//   //   imageUrl:'http://blog-assets.risingstack.com/2016/Jan/react_best_practices-1453211146748.png',
//   //   trainer:'Sumeet',
//   //   location:'Hyderabad'
//   // }
//   // course2Info:ICourse={ 
//   //     name : 'AngularJS',
//   //   imageUrl:'https://i.ytimg.com/vi/hXfigUyeHaY/maxresdefault.jpg',    
//   //   trainer:'Sumeet',
//   //   location:'Bengaluru'
//   // }
//   courses:ICourse[]=[
//     { 
//       name : 'ReactJS',
//     imageUrl:'http://blog-assets.risingstack.com/2016/Jan/react_best_practices-1453211146748.png',
//     trainer:'Sumeet',
//     location:'Hyderabad'
//   },
//   { 
//       name : 'AngularJS',
//     imageUrl:'https://i.ytimg.com/vi/hXfigUyeHaY/maxresdefault.jpg',    
//     trainer:'Sumeet',
//     location:'Bengaluru'
//   }
//   ];
//  }
var AppComponent = (function () {
    function AppComponent() {
    }
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            // template: `<shoppingcart></shoppingcart>`
            // template:`<useproductservice></useproductservice>
            // <useproductservice></useproductservice>`
            //template:`<posts></posts>`,
            template: "\n  \n\n  <nav>  \n            <a routerLink=\"/posts\" class=\"btn btn-primary\">Posts</a>\n            <a routerLink=\"/cart\" class=\"btn btn-primary\">Cart</a>            \n  </nav>\n\n  <router-outlet></router-outlet>\n\n  \n  "
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map