 import { Component } from '@angular/core';
 import {ProductService} from './product.service';

@Component({
   selector: 'useproductservice',
    template: `
    <div style="width:500px;border:2px solid red;border-radius:10px;padding:20px;margin:20px;">
        <h1>Product Service Component</h1>
        <input type="text" [(ngModel)]="productToBeAdded" /> {{productReceived}}  <br/>
        <input type="button" (click)="AddProduct()" value="Add Product>>" class="btn btn-primary" />
        <input type="button" (click)="GetProduct()" value="Get Random Product" class="btn btn-danger" />
        
    </div>    
    `,    providers:[ProductService]
 })
 export class ProductServiceComponent  { 
    productToBeAdded:string="";
    productReceived:string="";
    constructor(private serviceObj:ProductService){ // DI

    }

    AddProduct(){
        this.serviceObj.insertNewProduct(this.productToBeAdded);
    }

    GetProduct(){
      this.productReceived =   this.serviceObj.getRandomProduct();
    }
 }