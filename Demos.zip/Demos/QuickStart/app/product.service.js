"use strict";
var ProductService = (function () {
    function ProductService() {
        this.products = ['Mobile', 'laptop', 'LED TV', 'Camera'];
    }
    ProductService.prototype.getProducts = function () {
        return this.products;
    };
    ProductService.prototype.insertNewProduct = function (newProduct) {
        this.products.push(newProduct);
    };
    ProductService.prototype.getRandomProduct = function () {
        return this.products[Math.floor(Math.random() * this.products.length)];
    };
    return ProductService;
}());
exports.ProductService = ProductService;
//# sourceMappingURL=product.service.js.map