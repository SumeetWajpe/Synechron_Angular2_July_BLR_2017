import {Component} from '@angular/core';
import {PostsService} from './posts.service';
@Component({
   selector: 'posts',  
   template:` <h2> Posts </h2>
   <div>
        <ul>
            <li *ngFor="let p of postsData">
               <a [routerLink]="['/post',p.id]"> {{p.title}} </a>
            </li>
        </ul>
   </div>`,
   providers:[PostsService]
 })
export class PostsComponent{
    postsData:any;
constructor(private postsServObj:PostsService){
    // this.postsServObj.getPosts( (dataFromServer:any)=>{
    //     // use the data
    //     this.postsData = dataFromServer;
    // });
}

ngOnInit(){
  let returnedPromise =   this.postsServObj.getPosts();
  returnedPromise.then(
      (response)=>{
      this.postsData = response.json();
     },
    (error)=>{
      console.log('Something went wrong !' + error);
     }
);
}
}