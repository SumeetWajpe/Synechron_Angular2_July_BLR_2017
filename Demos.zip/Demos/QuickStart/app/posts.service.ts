import {Http} from '@angular/http';
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PostsService{
    constructor(private http:Http){
       
    }
    // getPosts(){
    //     // make ajaxified request
    //     this.http.get('https://jsonplaceholder.typicode.com/posts')
    //     .subscribe(res => console.log(res.json()));
    // }

    // getPosts(callBackFunc:any){
    //     // make ajaxified request
    //   return  this.http.get('https://jsonplaceholder.typicode.com/posts')
    //     .subscribe(res => callBackFunc(res.json()));
    // }

    getPosts(){
        // make ajaxified request
      return  this.http.get('https://jsonplaceholder.typicode.com/posts').toPromise();
    
    }

}