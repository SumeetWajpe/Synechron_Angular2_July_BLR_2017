export class ProductService{
    products:string[] = ['Mobile','laptop','LED TV','Camera'];

getProducts():string[]{
    return this.products;
}

insertNewProduct(newProduct:string):void{
    this.products.push(newProduct);
}


getRandomProduct():string{
return this.products[Math.floor(Math.random() * this.products.length)];
}

}