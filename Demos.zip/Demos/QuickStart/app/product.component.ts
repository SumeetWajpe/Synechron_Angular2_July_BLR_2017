import {Component,Input} from '@angular/core';

@Component({
    selector:'product',    
    template:`
    <div class="Product" productStyle productColor="lightgreen">
    <h2> {{prodDetails.name | uppercase  }} </h2>
                    <b> Price :  </b> {{prodDetails.price | currency:'INR':true  }} <br/>
                    <b> Quantity :  </b> {{prodDetails.quantity | number}} <br/>
                    <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2'   }} <br/>
                    <b> Date : </b> {{prodDetails.launchdate | date:'MMM yyyy'  }}  <br/>
                    <b> Description : </b> {{prodDetails.description | cutshort:50 }}
        </div>  ` ,
//         styles:[`                      
//       .Product{
//         background-color:lightblue;
//         border:2px solid black;
//         border-radius:10px;
//         padding:20px;
//         margin:20px;
//       }
//    ` ]  

styleUrls:['./app/ProductStyles.css']               
})
export class ProductComponent{
 @Input('pDetails')   prodDetails:any={};
}