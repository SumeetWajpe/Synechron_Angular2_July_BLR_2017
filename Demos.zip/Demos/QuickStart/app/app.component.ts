 import { Component } from '@angular/core';
// import {ICourse} from './iCourse.interface';
// @Component({
//   selector: 'my-app',
//   // template: `<course [coursedetails]="course1Info"></course>
//   // <course [coursedetails]="course2Info"></course>`,


// // template:`
// // <h1> Courses :</h1>

// // <div *ngFor="let c of courses">
// //       <course [coursedetails]="c"></course>
// // </div>
// // `

// templateUrl:'./app/app.component.html'
// })
// export class AppComponent  { 
//   // course1Info:ICourse={ 
//   //     name : 'ReactJS',
//   //   imageUrl:'http://blog-assets.risingstack.com/2016/Jan/react_best_practices-1453211146748.png',
//   //   trainer:'Sumeet',
//   //   location:'Hyderabad'
//   // }
//   // course2Info:ICourse={ 
//   //     name : 'AngularJS',
//   //   imageUrl:'https://i.ytimg.com/vi/hXfigUyeHaY/maxresdefault.jpg',    
//   //   trainer:'Sumeet',
//   //   location:'Bengaluru'
//   // }

//   courses:ICourse[]=[
//     { 
//       name : 'ReactJS',
//     imageUrl:'http://blog-assets.risingstack.com/2016/Jan/react_best_practices-1453211146748.png',
//     trainer:'Sumeet',
//     location:'Hyderabad'
//   },
//   { 
//       name : 'AngularJS',
//     imageUrl:'https://i.ytimg.com/vi/hXfigUyeHaY/maxresdefault.jpg',    
//     trainer:'Sumeet',
//     location:'Bengaluru'
//   }
//   ];
//  }


@Component({
   selector: 'my-app',
   // template: `<shoppingcart></shoppingcart>`
  // template:`<useproductservice></useproductservice>
  // <useproductservice></useproductservice>`
  //template:`<posts></posts>`,
  template:`
  

  <nav>  
            <a routerLink="/posts" class="btn btn-primary">Posts</a>
            <a routerLink="/cart" class="btn btn-primary">Cart</a>            
  </nav>

  <router-outlet></router-outlet>

  
  `
 })
 export class AppComponent  { }