import {Component} from '@angular/core';
import{ActivatedRoute} from '@angular/router';

@Component({
   selector: 'posts',  
   template:` <h2> Post details for {{ postId  }} </h2>
   <div>
       
   </div>`
 })
export class PostDetailComponent{
    postId:number;
    constructor(private route:ActivatedRoute){

    }

    ngOnInit(){
        this.route.params.subscribe(
            p => this.postId = p['id']
        )
    }


}