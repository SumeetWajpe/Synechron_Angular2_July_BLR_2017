import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {RouterModule,Routes} from '@angular/router';

import { AppComponent }  from './app.component';
import {CourseComponent} from './course.component';
import {ShoppingCartComponent} from './shoppingcart.component';
import {ProductComponent} from './product.component';
import {ProductServiceComponent} from './useproductservice';
import {PostsComponent} from './posts.component';
import {PostDetailComponent} from './postdetail.component';


 import {ProductService} from './product.service';

import {CutShortPipe} from './cutshort.pipe';

import {HoverDirective}from './hoverOnProducts.directive';


const routes:Routes=[
  {path:'posts',component:PostsComponent},  
  {path:'post/:id',component:PostDetailComponent},    
  {path:'cart',component:ShoppingCartComponent},
  {path:'',redirectTo:'/posts',pathMatch:'full'},
  {path:'**',redirectTo:'/cart',pathMatch:'full'}
];

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,
    RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,CourseComponent,
  ProductComponent,ShoppingCartComponent,
  CutShortPipe,HoverDirective
  ,ProductServiceComponent,PostsComponent,PostDetailComponent ],
  bootstrap:    [ AppComponent ],
  providers:[ProductService]
})
export class AppModule { }
